import GoogleProductScrapper from "./index";

GoogleProductScrapper({ searches: `apple\nslider` });