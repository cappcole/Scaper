#!/bin/bash
act push  -j 'Crawlora-App-Publis' --container-architecture linux/amd64 --secret-file .secrets --rm -w